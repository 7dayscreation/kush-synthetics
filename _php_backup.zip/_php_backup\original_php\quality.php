<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<title>Kush Synthetics Pvt.Ltd.</title>
	<meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
	<meta name="generator" content="2014.2.1.284"/>
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no" />
  
	<link rel="shortcut icon" href="favicon.ico"/>
  	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
  	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
  	<link rel="stylesheet" type="text/css" href="css/style.css"/>

</head>

<body>
	<div class="preload"><ul class="loader"><li></li><li></li><li></li></ul></div>
      <header>
         <div class="container">
             <div class="row">
                     <div class="logo"><a href="index.php"><img src="images/logo.png" alt=""/></a></div>
                          <div class="nav-menu-icon">
                              <a href="#"><i></i></a>
                          </div> 
             </div>
             <div class <a href="#"><i></i></a>
                          </div> 
             </div>
             <div class="row">
                       <div class="navigation">
                           <nav> 
                              <a href="index.php" class="active">HOME</a>
                              <a href="about.php">ABOUT</a>
                              <a href="products.php">PRODUCTS</a>
                              <a href="quality.php">QUALITY</a>
                              <a href="news.php">NEWS</a>
                              <a href="contact.php">CONTACT</a>
                           </nav>
                       </div>
              </div>
         </div>
      </header>

	<div class="container">
		<div class="main-container news-post">
			<div class="row">
            	<div class="col-md-4">
                	<div class="row">
                    	<div class="news-left-desc bg-grey news-desc">
							<h4>OUR QUALITY</h4>
							<p align="justify">Kush's Quality Management System (QMS) is certified by Det Norske Veritas under ISO 9001:2008.</p>
             
                         </div>
                     </div>
                  </div>
                  <div class="col-md-8">
                     <div class="row">
                        <div class="news-right-desc">
                            <img src="images/world.jpg" alt="post picture">
                        </div>
                     </div>
                  </div>
              </div>
			<div class="row">
            	<div class="col-md-12">
					<div class="row">
						<div class="news-text bg-white">
							<h4>QUALITY CONTROL CERTIFICATION</h4><br>
							<p align="justify">
In ever respect of its work - production and customer service included - Kush aims to reach one ambitious goal: Excellence. At Kush, we take pride in delivering fabrics that exceed our customers' expectations. We have made it our policy to overcome production and development barriers through effective Quality Management System.<br><br>
Kush's Quality Management System (QMS) is certified by Det Norske Veritas under ISO 9001:2008. This QMS lays the foundation for our business and our day to day practices are governed by procedures and instructions supported by the QMS.<br><br>Furthermore, range of Kush's fabrics are approved by Germanischer Lloyd.</p><br><br>
						
							<h4>TESTING AT RAW MATERIAL STAGE</h4><br>
							<p align="left">
								10 Samples are randomly drawn from the raw materials received, for 2 different tests<br><br>
								1. Testing of Te Tolerance level for fibreglass with Tex 2400, 1200, 600 is set at ± 8%, and for 300 Tex roving is ± 6%<br>
								2. Loss On Ignition (LOI) LOI should always be less then 2%.
							</p><br><br>
							
							<h4>CONTROL AND CERTIFICATION</h4><br>
							<p align="justify">
								We pride ourselves on delivering actionable strategies that produce results. our products is clean and focuses on the simplicity of the message and ease of use.
							</p><br><br>
							
							<h4>TEST ON FINISHED FABRICS</h4><br>
							<p align="justify">
								At least one finished fabric sample is randomly drawn from the production of |each and every machine for the following tests<br><br>
								1. <b>Total fabric GSM</b> Actual weight, of a finished sample, should be within ± 5% of the intended weight of the fabric<br>
								2. <b>Layer wise GSM</b> Actual weight of a layer of a finished sample should be within ± 5% of the intended weigh on the fabric<br>
								3. <b>Stitch Density</b> Samples of finished goods are checked for density of stitches per Sq. Inch. The density varies according to fabric requirements<br>
								4. <b>Moisture Content</b> Every sample drawn is checked for moisture content, and the moisture content should not exceed 0.5%
							</p><br><br>
						</div>
						
					</div>
				</div>  
			</div>
			
			
		</div>
	</div>


	<?php include 'footer.php'; ?>

</body>
</html>